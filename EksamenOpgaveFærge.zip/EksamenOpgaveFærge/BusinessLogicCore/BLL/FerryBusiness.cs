﻿using DataAccessCore.Repositories;
using DTOCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogicCore.BLL
{
    public class FerryBusiness
    {
        public FerryDTO FindFerry(string name)
        {
            return FerryRepository.FindFerry(name);
        }

        public List<FerryDTO> GetAllFerries()
        {
            return FerryRepository.GetAllFerries();
        }
    }
}

/*public class FerryBusiness
{
    public DTO.Ferry FindFerry(string id)
    {
        return FerryRepository.FindFerry(id);
    }

    public List<DTO.Ferry> GetAllFerries()
    {
        return FerryRepository.GetAllFerries();
    }

    public void AddFerry(DTO.Ferry ferry)
    {
        FerryRepository.AddFerry(ferry);
    }

    public void DeleteFerry(DTO.Ferry ferry)
    {
        FerryRepository.DeleteFerry(ferry);
    }

    public void EditFerry(DTO.Ferry ferry)
    {
        FerryRepository.EditFerry(ferry);
    }
}*/
