﻿using DataAccessCore.Repositories;
using DTOCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogicCore.BLL
{
    public class CarBusiness
    {
        public CarDTO FindCar(string model)
        {
            return CarRepository.FindCar(model);
        }
    }
}
