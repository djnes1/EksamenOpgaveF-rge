﻿using DataAccessCore.Repositories;
using DTOCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogicCore.BLL
{
    public class GuestBusiness
    {
        public GuestDTO FindGuest(string name)
        {
            return GuestRepository.FindGuest(name);
        }

        public void AddGuest(GuestDTO guest)
        {
           GuestRepository.AddGuest(guest);
        }

        public void RemoveGuest(GuestDTO guest)
        {
            GuestRepository.RemoveGuest(guest);
        }

    }
}
