﻿using DataAccessCore.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessCore.Mappers
{
    internal class FerryMapper
    {
        internal static DTOCore.FerryDTO Map(Ferry ferry)
        {
            return new DTOCore.FerryDTO(ferry.Name);
        }

        internal static Ferry Map(DTOCore.FerryDTO ferryDTO)
        {
            return new Ferry(ferryDTO.Name);
        }

        public static List<Ferry> MapAll(List<DTOCore.FerryDTO> ferries)
        {
            List<Ferry> ret = new List<Ferry>();
            foreach (DTOCore.FerryDTO ferryDTO in ferries)
            {
                ret.Add(Map(ferryDTO));
            }
            return ret;
        }

        public static List<DTOCore.FerryDTO> MapAll(List<Ferry> ferries)
        {
            List<DTOCore.FerryDTO> ret = new List<DTOCore.FerryDTO>();
            foreach (var ferry in ferries)
            {
                ret.Add(Map(ferry));
            }
            return ret;
        }
    }
}
