﻿using DataAccessCore.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessCore.Mappers
{
    internal class GuestMapper
    {
        internal static DTOCore.GuestDTO Map(Guest guest)
        {
            return new DTOCore.GuestDTO(guest.Name, guest.Gender, guest.Phone, guest.IsDriver, guest.ID);        
        }
        internal static Guest Map(DTOCore.GuestDTO guestDTO)
        {
            return new Guest(guestDTO.Name, guestDTO.Gender, guestDTO.Phone, guestDTO.IsDriver, guestDTO.ID);            
        }
    }
}
