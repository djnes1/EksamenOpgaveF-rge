﻿using DataAccessCore.Mappers;
using DataAccessCore.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessCore.Mappers
{
    internal class CarMapper
    {
        internal static DTOCore.CarDTO Map(Car car)
        {
            return new DTOCore.CarDTO(car.Model, car.RegNr);
        }

        internal static Car Map(DTOCore.CarDTO carDTO)
        {
            return new Car(carDTO.Model, carDTO.RegNr);
        }

        public static List<Car> MapAll(List<DTOCore.CarDTO> cars)
        {
            List<Car> ret = new List<Car>();
            foreach (DTOCore.CarDTO car in cars)
            {
                ret.Add(CarMapper.Map(car));
            }
            return ret;
        }

        public static List<DTOCore.CarDTO> MapAll(List<Car> cars)
        {
            List<DTOCore.CarDTO> ret = new List<DTOCore.CarDTO>();
            foreach (var car in cars)
            {
                ret.Add(Map(car));
            }
            return ret;
        }
    }

}



