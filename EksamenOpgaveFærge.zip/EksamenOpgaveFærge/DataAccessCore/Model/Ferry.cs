﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessCore.Model
{
    internal class Ferry
    {
        public string Name { get; set; }
        public List<Car> Cars { get; set; }

        public Ferry() { }
        public Ferry(string name)
        {
            Name = name;
        }
    }
}
