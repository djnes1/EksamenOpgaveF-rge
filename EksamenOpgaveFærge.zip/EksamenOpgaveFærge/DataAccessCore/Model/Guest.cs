﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessCore.Model
{
    internal class Guest
    {
        public string Name { get; set; }
        public string Gender { get; set; }
        public string Phone { get; set; }
        public bool IsDriver { get; set; }
        public string ID { get; set; }


        public Guest() { }
        public Guest(string name, string gender, string phone, bool isDriver, string id)
        {
            Name = name;
            Gender = gender;
            Phone = phone;
            IsDriver = isDriver;
            ID = id;
        }
    }
}
