﻿using DataAccessCore.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessCore.Context
{
    internal class FerryContext : DbContext
    {
        internal FerryContext()
        {
            bool created = Database.EnsureCreated();
            if (created)
            {
                Debug.WriteLine("Database created");
            }
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=DinesLaptop\\SQLEXPRESS;Initial Catalog=FerryApp;Integrated Security=SSPI; TrustServerCertificate=true");
            optionsBuilder.LogTo(message => Debug.WriteLine(message));
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder) // læser startdata
        {
            //Guest guest1 = new Guest("John Doe", "male", "123456789", true, "1");
            //Guest guest2 = new Guest("Jane Smith", Guest.GenderEnum.Female, "987654321", false, null);
            //Guest guest3 = new Guest("Chris Johnson", Guest.GenderEnum.Male, "555555555", true, null);
            //Guest guest4 = new Guest("Alicia Rodriguez", Guest.GenderEnum.Female, "999888777", false, null);
            //List<Guest> guestsTest = new List<Guest>();
            //guestsTest.Add(guest1); guestsTest.Add(guest2); guestsTest.Add(guest3); guestsTest.Add(guest4);

            modelBuilder.Entity<Guest>().HasKey(g => g.Name);
            modelBuilder.Entity<Guest>().HasData(new Guest[] {
                new Guest("John Doe", "male", "12345678", true, "1"),
                new Guest("Jane Smith", "female" , "98765432", false, "2"),
                new Guest("Chris Johnson", "male", "55555555", true, "3"),
                new Guest("Alicia Rodriguez", "female", "99988877", false, "4")
            });

            modelBuilder.Entity<Car>().HasKey(c => c.Model);
            modelBuilder.Entity<Car>().HasData(new Car[] {
                new Car("Honda", "HO12345"),
                new Car("Opel", "OP12345"),
                new Car("Audi", "AU12345")
            });

            modelBuilder.Entity<Ferry>().HasKey(f => f.Name);
            modelBuilder.Entity<Ferry>().HasData(new Ferry[] {
                new Ferry("MS Sømil"),
                new Ferry("MS TurboBåd")
            });
        }

        public DbSet<Guest> Guests { get; set; }
        public DbSet<Car> Cars { get; set; }
        public DbSet<Ferry> Ferrys { get; set; }

    }
}
