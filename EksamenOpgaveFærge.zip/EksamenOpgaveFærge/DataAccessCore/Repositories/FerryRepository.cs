﻿using DataAccessCore.Context;
using DataAccessCore.Mappers;
using DTOCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessCore.Repositories
{
    public class FerryRepository
    {
        public static FerryDTO FindFerry(string name)
        {
            using (FerryContext ferryContext = new FerryContext())
            {
                return FerryMapper.Map(ferryContext.Ferrys.Find(name));
            }
        }
        public static List<FerryDTO> GetAllFerries()
        {
            using (FerryContext ferryContext = new FerryContext())
            {
                return FerryMapper.MapAll(ferryContext.Ferrys.ToList());
            }
        }
    }
}