﻿using DataAccessCore.Context;
using DataAccessCore.Mappers;
using DTOCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessCore.Repositories
{
    public class GuestRepository
    {
        public static GuestDTO FindGuest(string name)
        {
            using (FerryContext ferryContext = new FerryContext())
            {
                return GuestMapper.Map(ferryContext.Guests.Find(name));
            }
        }

        public static void AddGuest(GuestDTO guestDTO) 
        {
            using (FerryContext ferryContext = new FerryContext())
            {
                Model.Guest dataGuest = GuestMapper.Map(guestDTO);
                ferryContext.Guests.Add(dataGuest);
                ferryContext.SaveChanges();
            }          
        }

        public static void RemoveGuest(GuestDTO guestDTO)
        {
            using (FerryContext ferryContext = new FerryContext())
            {
                Model.Guest dataGuest = GuestMapper.Map(guestDTO);
                ferryContext.Guests.Remove(dataGuest);
                ferryContext.SaveChanges();
            }
        }
    }
}


  /*  public static void AddGuest(DTO.Guest guest, string ferryId)
    {
        using (FerryContext context = new FerryContext())
        {

            Model.Guest dataGuest = GuestMapper.Map(guest);
            dataGuest.FerryId = ferryId;
            context.Guests.Add(dataGuest);
            context.SaveChanges();
        }
    }
}*/

