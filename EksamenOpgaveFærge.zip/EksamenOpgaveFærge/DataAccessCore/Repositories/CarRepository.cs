﻿using DataAccessCore.Context;
using DataAccessCore.Mappers;
using DTOCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessCore.Repositories
{
    public class CarRepository
    {
        public static CarDTO FindCar(string model)
        {
            using (FerryContext ferryContext = new FerryContext())
            {
                return CarMapper.Map(ferryContext.Cars.Find(model));
            }
        }
    }
}
