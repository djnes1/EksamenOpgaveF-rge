﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTOCore
{
    public class GuestDTO
    {
        public string Name { get; set; }
        public string Gender { get; set; }
        public string Phone { get; set; }
        public bool IsDriver { get; set; }
        public string ID { get; set; }
        //public FerryDTO AssignedFerry { get; set; }

        public GuestDTO() { }   
        public GuestDTO(string name, string gender, string phone, bool isDriver, string id)
        {
            Name = name;
            Gender = gender;
            Phone = phone;
            IsDriver = isDriver;
            ID = id;
        }
    }
}
