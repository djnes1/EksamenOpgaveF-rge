﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTOCore
{
    public class FerryDTO
    {
        public string Name { get; set; }
        public int MaxCarsCapacity { get; set; }
        public List<CarDTO> Cars { get; set; }

        public FerryDTO(string name)
        {
            Name = name;
        }
    }
}
