﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTOCore
{
    public class CarDTO
    {
        public string Model { get; set; }
        public string RegNr { get; set; }

        public CarDTO(string model, string regNr)
        {
            Model = model;
            RegNr = regNr;
        }
    }
}
