﻿using DTOCore;
using System.Text.Json;

HttpClient client = new HttpClient();

var stringTask = client.GetStringAsync("https://localhost:7164/api/car/honda");
var msg = stringTask.Result;
var option = new JsonSerializerOptions
{
    PropertyNameCaseInsensitive = true
};
CarDTO car = JsonSerializer.Deserialize<CarDTO>(msg, option);
Console.WriteLine("Model: " + car.Model + ", RegNr: " + car.RegNr);

Console.ReadLine();
