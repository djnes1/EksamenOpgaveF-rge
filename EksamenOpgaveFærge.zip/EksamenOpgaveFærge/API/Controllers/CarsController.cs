﻿using BusinessLogicCore.BLL;
using DTOCore;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarController : ControllerBase
    {
        [HttpGet("car/{model}")]
        public CarDTO GetCar(string model)
        {
            CarBusiness sb = new CarBusiness();
            return sb.FindCar(model);
        }
    }
}
