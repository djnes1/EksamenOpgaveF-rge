﻿using BusinessLogicCore.BLL;
using DTOCore;
using Microsoft.AspNetCore.Mvc;

namespace FærgeMVC.Controllers
{
    public class GuestController : Controller
    {
        public IActionResult Index()
        {
         
            return View();
        }

        [HttpPost]
        public IActionResult PostGuest(GuestDTO guestDTO)
        {
            var guestBusiness = new GuestBusiness();
            guestBusiness.AddGuest(guestDTO);


            return View();
        }

        public IActionResult GuestForm()
        {

            return View();
        }

        public IActionResult AddGuest(GuestDTO guest)
        {
            GuestBusiness gege = new GuestBusiness();

            gege.AddGuest(guest);
                
       
            return View();
        }

        public IActionResult RemoveGuestForm()
        {

            return View();
        }

        public IActionResult RemoveGuest(GuestDTO guest)
        {
            GuestBusiness gege = new GuestBusiness();

            gege.RemoveGuest(guest);


            return View();
        }

    }
}

