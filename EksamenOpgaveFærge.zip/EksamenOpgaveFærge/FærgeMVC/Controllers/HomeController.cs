﻿using FærgeMVC.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using BusinessLogicCore.BLL;
using DTOCore;

namespace FærgeMVC.Controllers
{
    public class HomeController : Controller
    {

        public IActionResult Index()
        {
            //CarBusiness business = new CarBusiness();

            //CarDTO car = business.FindCar("Honda");

            //FerryBusiness ferry = new FerryBusiness();

            //FerryDTO ferry1 = ferry.FindFerry("ferry1");

            FerryBusiness ferries = new FerryBusiness();

            List<FerryDTO> allFerries = ferries.GetAllFerries();

            //GuestBusiness guest = new GuestBusiness();

            //GuestDTO guest1 = guest.FindGuest("John Doe");

            return View(allFerries);
        }
    }
}